"""VerilatorSimClient: drop-in replacement for XSimClient, backed by the decomp_sim extension.

It answers the same calls the env makes and produces the same @OBS lines tb_interactive.sv prints,
so DecoderEnvXSim keeps its parsing and bookkeeping unchanged:

    from .verilator_sim_client import VerilatorSimClient as XSimClient

Call sequence the env uses, and what happens here:
    start() / restart()           new simulation, before the testbench handshake
    resume(); wait_for_obs(cb)    -> handshake reached (no @OBS line)
    write_action(stem)            image prefix: <stem>_subdec<s>_rows.hex
    resume(); wait_for_obs(cb)    -> golden rows loaded, reset run, cb(first @OBS line)
    write_action("1 <hex>")       one beat, as the env writes to action.txt ("%b %h")
    resume(); wait_for_obs(cb)    -> one clock cycle, cb(@OBS line)

Differences from xsim:
  * If the RTL hits $stop / $fatal (an assertion on a malformed beat), resume() raises
    decomp_sim.RtlStop. xsim would pause and the env would keep reading stale state.
  * No files are written (no action.txt), no subprocess, no Tcl.

For speed, skip the text round trip: use `sim` directly (step_beat / step_idle /
skip_until_ready) and build hw_state with hw_state_dict(); see README.md.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable

try:
    from . import decomp_sim  # type: ignore[attr-defined]
except ImportError:  # imported as a top-level module (python/ on sys.path)
    import decomp_sim  # type: ignore[no-redef]

SUB_DECODER_FIELDS = ("cmd", "lit1", "lit2", "lit3", "lit4", "out")


class VerilatorSimClient:
    def __init__(self, run_dir: str | Path | None = None, verbose: bool = False,
                 max_steps: int = 1_000_000, release_at_edge: bool = True):
        """run_dir is accepted for XSimClient compatibility and ignored."""
        self.verbose = verbose
        self.max_steps = max_steps
        self.release_at_edge = release_at_edge
        self.sim: decomp_sim.DecompSim | None = None
        self._phase = "closed"          # closed | fresh | handshake | running | stopped
        self._pending: str | None = None
        self._lines: list[str] = []
        self._stem: str | None = None

    # ------------------------------------------------------------------ process control
    @property
    def is_running(self) -> bool:
        return self._phase != "closed"

    def start(self):
        self.sim = decomp_sim.DecompSim(self.max_steps, self.verbose, self.release_at_edge)
        self._phase = "fresh"
        self._pending = None
        self._lines.clear()

    def restart(self):
        if self.sim is None:
            self.start()
            return
        self._phase = "fresh"
        self._pending = None
        self._lines.clear()

    def close(self):
        self.sim = None
        self._phase = "closed"
        self._lines.clear()

    # ------------------------------------------------------------------ ping-pong
    def write_action(self, text: str):
        self._pending = text.strip()

    def resume(self):
        if self._phase == "closed":
            raise RuntimeError("simulator not started")
        if self._phase == "stopped":
            raise RuntimeError("the RTL stopped; restart() before stepping again")

        if self._phase == "fresh":                       # run to @HANDSHAKE_READY
            self._phase = "handshake"
            return

        action, self._pending = self._pending, None
        if self._phase == "handshake":
            if action is None:                           # resumed without a stem: stay paused
                return
            stem = action.split()[0]
            self.sim.load_reference(stem)
            self.sim.reset()
            self._stem = stem
            self._phase = "running"
            self._lines.append(self.sim.obs_line())
            return

        # running: one clock cycle per action
        if action is None:
            raise RuntimeError("resume() without write_action() (the testbench would re-read "
                               "the previous action.txt; write the action explicitly)")
        valid, data = self._parse_action(action)
        try:
            self.sim.step_int(valid, data)
        except decomp_sim.RtlStop:
            self._phase = "stopped"
            raise
        self._lines.append(self.sim.obs_line())

    def wait_for_obs(self, callback: Callable[[str], None] | None = None):
        lines, self._lines = self._lines, []
        if callback is not None:
            for line in lines:
                callback(line)
        return lines

    @staticmethod
    def _parse_action(action: str) -> tuple[bool, int]:
        """Same as the testbench's $fscanf("%b %h"): valid bit, then the beat in hex."""
        parts = action.split()
        if len(parts) != 2:
            raise RuntimeError(f"Python closed loop or action invalid: {action!r}")
        valid = int(parts[0], 2)
        data = int(parts[1].replace("_", ""), 16)
        return bool(valid), data

    # ------------------------------------------------------------------ fast path helpers
    def hw_state_dict(self) -> dict:
        """hw_state built straight from the model, without formatting and parsing a text line.

        Key names follow env.py's usage. Check them once against your parse_obs_line:
            assert client.hw_state_dict() == parse_obs_line(client.sim.obs_line())
        """
        sim = self.sim
        counts = sim.lane_counts()
        return {
            "top_in_ready": int(sim.in_ready),
            "top_row_valid": int(sim.row_valid),
            "mismatches": sim.total_mismatches,
            "sub_decoders": [dict(zip(SUB_DECODER_FIELDS, map(int, row))) for row in counts],
            "tail_busy": [int(x) for x in sim.tail_busy()],
            "cmd_popped": [int(x) for x in sim.cmd_popped()],
            "rows_out": sim.outp_rows,
            "rows_consumed": sim.rows_consumed,
            "lane_mismatches": sim.lane_mismatches,
            "proto_err": sim.proto_err,
            "tailbusy_hits": sim.tailbusy_hits,
            "cmd_overcommit": sim.cmd_overcommit,
            "ready_viol": sim.ready_viol,
        }
