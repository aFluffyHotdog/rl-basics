// DecompSim -- C++ replacement for tb_interactive.sv, driving the Verilated rl_top_wrapper.
//
// Timing model (identical to tb_interactive.sv):
//   * Reset: rst_n = 0, 10 rising edges, rst_n = 1, 5 more rising edges. The first decision
//     point is the falling edge after that (wall cycle 1).
//     The testbench sets rst_n = 1 in the same time step as the 10th rising edge, which is a race
//     in Verilog. Verilator's own run of the testbench (and, judging by cycle-exact matches on the
//     v20 testbench, xsim) lets the flops see the release at that edge: release_at_edge = true.
//     It matters: the arbiter's free-running skid_try_r counter keeps the phase forever.
//   * Each decision point is a falling edge. There the observation is read, the beat is checked
//     (check_beat) and driven; the DUT samples it at the next rising edge.
//   * Counters the testbench keeps with `always @(posedge clk)` (cmd_popped, rows_emitted,
//     lane/pin mismatches, outp_rows) sample the signals just before the rising edge, like
//     nonblocking assignments do.
#pragma once

#include <array>
#include <cstdint>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

class VerilatedContext;
class Vrl_top_wrapper;

namespace decomp {

constexpr int kNumSubdecs = 8;
constexpr int kNumRows = 720;
constexpr int kCmdFifoDepth = 16;
constexpr int kObsFields = 74;     // @OBS fields 0..73, same order as tb_interactive.sv

// The RTL executed $stop, $finish or $fatal (for example an assertion in new_dec_sub_rx on a
// malformed beat). xsim would pause there; here the cycle completes and step() throws. The sim
// must be reset before it is stepped again.
struct RtlStop : std::runtime_error {
    using std::runtime_error::runtime_error;
};

using Row128 = std::array<uint32_t, 4>;     // word 0 = bits 31:0
using Beat135 = std::array<uint32_t, 5>;    // word 0 = bits 31:0, word 4 holds bits 134:128

struct LaneCounts {
    int cmd = 0, lit1 = 0, lit2 = 0, lit3 = 0, lit4 = 0, out = 0;
};

class DecompSim {
public:
    explicit DecompSim(uint64_t max_steps = 1000000, bool verbose = false,
                       bool release_at_edge = true);
    ~DecompSim();
    DecompSim(const DecompSim&) = delete;
    DecompSim& operator=(const DecompSim&) = delete;

    // Golden rows: reads <stem>_subdec<s>_rows.hex for s = 0..7 (same as load_all_subdecs).
    // Without a reference, rows are still counted but never compared.
    void load_reference(const std::string& stem);
    void clear_reference();
    bool has_reference() const { return has_ref_; }

    // Full reset sequence. Afterwards the sim is at the first decision point (cycle 1).
    void reset();

    // One clock cycle with the given beat (the body of the testbench's RL loop).
    void step(bool valid, const Beat135& data);
    void step_hex(bool valid, const std::string& hex);              // "%b %h" form
    void step_beat(int dest, int ncmd, const std::array<uint16_t, 8>& slots);
    void step_idle();

    // Idle cycles while in_ready is low, at most max_cycles. Returns the number of cycles run.
    int skip_until_ready(int max_cycles);

    // ---- observation (state at the current decision point)
    bool in_ready() const;
    bool row_valid() const;
    LaneCounts lane_counts(int s) const;
    bool tail_busy(int s) const;
    int cmd_popped(int s) const { return cmd_popped_[s]; }
    int rows_emitted(int s) const { return rows_emitted_[s]; }
    int outp_rows() const { return outp_rows_; }
    int rows_consumed() const;
    int total_mismatches() const { return total_mismatches_; }
    int lane_mismatches() const { return lane_mm_total_; }
    int proto_err() const { return proto_err_; }
    int tailbusy_hits() const { return tailbusy_hits_; }
    int cmd_overcommit() const { return cmd_overcommit_; }
    int ready_viol() const { return ready_viol_; }
    uint64_t cycle() const { return wall_cyc_; }

    // Called from the Verilator runtime hooks ($stop / $finish / $fatal inside the RTL).
    void note_rtl_stop(const std::string& what);

    std::array<int64_t, kObsFields> obs_fields() const;
    std::string obs_line() const;   // byte-identical to the testbench's @OBS line

private:
    void eval();
    void posedge();
    void negedge();
    void drive(bool valid, const Beat135& data);
    void check_beat(bool valid, const Beat135& data);
    void enter_decision_point();
    bool row_matches(const Row128& got, int s, int row) const;
    Row128 lane_row(int s) const;
    Row128 pin_row(int s) const;

    std::unique_ptr<VerilatedContext> ctx_;
    std::unique_ptr<Vrl_top_wrapper> top_;
    uint64_t max_steps_;
    bool verbose_;
    bool release_at_edge_;

    bool has_ref_ = false;
    std::vector<std::array<Row128, kNumRows>> ref_;   // [lane][row]

    uint64_t wall_cyc_ = 0;
    bool started_ = false;
    std::string rtl_stop_;   // non-empty once the RTL stopped
    std::array<int, kNumSubdecs> cmd_popped_{};
    std::array<int, kNumSubdecs> cmd_committed_{};
    std::array<int, kNumSubdecs> rows_emitted_{};
    std::array<int, kNumSubdecs> mismatch_cnt_{};
    int outp_rows_ = 0, outp_pulses_ = 0, total_mismatches_ = 0, lane_mm_total_ = 0;
    int proto_err_ = 0, tailbusy_hits_ = 0, cmd_overcommit_ = 0, ready_viol_ = 0;
};

}  // namespace decomp
