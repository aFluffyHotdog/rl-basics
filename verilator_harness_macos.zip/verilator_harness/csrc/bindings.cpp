#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include "decomp_sim.h"

namespace py = pybind11;
using decomp::DecompSim;

namespace {

// Python int (up to 135 bits) -> five 32-bit words.
decomp::Beat135 beat_from_int(const py::int_& value) {
    decomp::Beat135 d{};
    py::object v = value;
    py::object mask = py::int_(0xFFFFFFFFu);
    for (int i = 0; i < 5; ++i) {
        d[i] = v.attr("__and__")(mask).cast<uint32_t>();
        v = v.attr("__rshift__")(32);
    }
    return d;
}

py::array_t<int32_t> lane_matrix(const DecompSim& sim) {
    py::array_t<int32_t> a({decomp::kNumSubdecs, 6});
    auto m = a.mutable_unchecked<2>();
    for (int s = 0; s < decomp::kNumSubdecs; ++s) {
        const auto c = sim.lane_counts(s);
        m(s, 0) = c.cmd; m(s, 1) = c.lit1; m(s, 2) = c.lit2;
        m(s, 3) = c.lit3; m(s, 4) = c.lit4; m(s, 5) = c.out;
    }
    return a;
}

template <typename F>
py::array_t<int32_t> per_lane(F f) {
    py::array_t<int32_t> a(decomp::kNumSubdecs);
    auto m = a.mutable_unchecked<1>();
    for (int s = 0; s < decomp::kNumSubdecs; ++s) m(s) = f(s);
    return a;
}

}  // namespace

PYBIND11_MODULE(decomp_sim, m) {
    m.doc() = "Verilated T8 decompressor with the tb_interactive.sv stepping and checks";
    m.attr("NUM_SUBDECS") = decomp::kNumSubdecs;
    m.attr("NUM_ROWS") = decomp::kNumRows;
    m.attr("OBS_FIELDS") = decomp::kObsFields;
    py::register_exception<decomp::RtlStop>(m, "RtlStop", PyExc_RuntimeError);

    py::class_<DecompSim>(m, "DecompSim")
        .def(py::init<uint64_t, bool, bool>(), py::arg("max_steps") = 1000000, py::arg("verbose") = false,
             py::arg("release_at_edge") = true,
             "release_at_edge: flops see reset released at the 10th rising edge (the testbench's "
             "race, resolved as Verilator and xsim do). False = one cycle later.")
        .def("load_reference", &DecompSim::load_reference, py::arg("stem"),
             "Read <stem>_subdec<s>_rows.hex for s = 0..7 (golden rows for the checks).")
        .def("clear_reference", &DecompSim::clear_reference)
        .def_property_readonly("has_reference", &DecompSim::has_reference)
        .def("reset", &DecompSim::reset, py::call_guard<py::gil_scoped_release>(),
             "Reset sequence; ends at the first decision point (cycle 1).")
        .def("step_hex", &DecompSim::step_hex, py::arg("valid"), py::arg("hex"),
             py::call_guard<py::gil_scoped_release>(),
             "One cycle, beat given as in action.txt: valid bit and 135-bit hex.")
        .def("step_int", [](DecompSim& s, bool valid, const py::int_& data) {
                 const auto d = beat_from_int(data);
                 py::gil_scoped_release release;
                 s.step(valid, d);
             }, py::arg("valid"), py::arg("data"), "One cycle, beat as a Python int (135 bits).")
        .def("step_beat", &DecompSim::step_beat, py::arg("dest"), py::arg("ncmd"), py::arg("slots"),
             py::call_guard<py::gil_scoped_release>(),
             "One cycle with a valid beat: lane, number of CMD groups, eight 16-bit slots.")
        .def("step_idle", &DecompSim::step_idle, py::call_guard<py::gil_scoped_release>())
        .def("skip_until_ready", &DecompSim::skip_until_ready, py::arg("max_cycles"),
             py::call_guard<py::gil_scoped_release>(),
             "Idle cycles while in_ready is low (at most max_cycles). Returns cycles run.")
        // observation
        .def_property_readonly("cycle", &DecompSim::cycle)
        .def_property_readonly("in_ready", &DecompSim::in_ready)
        .def_property_readonly("row_valid", &DecompSim::row_valid)
        .def_property_readonly("outp_rows", &DecompSim::outp_rows)
        .def_property_readonly("rows_consumed", &DecompSim::rows_consumed)
        .def_property_readonly("total_mismatches", &DecompSim::total_mismatches)
        .def_property_readonly("lane_mismatches", &DecompSim::lane_mismatches)
        .def_property_readonly("proto_err", &DecompSim::proto_err)
        .def_property_readonly("tailbusy_hits", &DecompSim::tailbusy_hits)
        .def_property_readonly("cmd_overcommit", &DecompSim::cmd_overcommit)
        .def_property_readonly("ready_viol", &DecompSim::ready_viol)
        .def("lane_counts", &lane_matrix,
             "int32[8, 6]: per lane cmd, lit1, lit2, lit3, lit4, out FIFO counts.")
        .def("tail_busy", [](const DecompSim& s) { return per_lane([&](int i) { return int(s.tail_busy(i)); }); })
        .def("cmd_popped", [](const DecompSim& s) { return per_lane([&](int i) { return s.cmd_popped(i); }); })
        .def("rows_emitted", [](const DecompSim& s) { return per_lane([&](int i) { return s.rows_emitted(i); }); },
             "Exact rows each lane has output (the testbench's lane-checker count).")
        .def("obs_fields", [](const DecompSim& s) {
                 const auto f = s.obs_fields();
                 py::array_t<int64_t> a(decomp::kObsFields);
                 std::copy(f.begin(), f.end(), a.mutable_data());
                 return a;
             }, "int64[74]: the @OBS fields in testbench order.")
        .def("obs_line", &DecompSim::obs_line, "The testbench's @OBS line, byte for byte.");
}
