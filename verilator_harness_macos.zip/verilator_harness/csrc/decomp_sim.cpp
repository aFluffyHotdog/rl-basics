#include "decomp_sim.h"

#include <algorithm>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <stdexcept>

#include "Vrl_top_wrapper.h"
#include "verilated.h"

namespace decomp {

namespace {

// The model being evaluated on this thread, for the Verilator runtime hooks below.
thread_local DecompSim* g_active = nullptr;

int hex_val(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c == '_') return -2;   // Verilog digit separator
    return -1;
}

// Parse a hex token into `nwords` little-endian 32-bit words (extra high digits are dropped).
template <size_t N>
std::array<uint32_t, N> parse_hex(const std::string& tok) {
    std::array<uint32_t, N> w{};
    int bit = 0;
    for (auto it = tok.rbegin(); it != tok.rend(); ++it) {
        int v = hex_val(*it);
        if (v == -2) continue;
        if (v < 0) throw std::invalid_argument("bad hex digit in '" + tok + "'");
        if (bit < static_cast<int>(N * 32)) w[bit / 32] |= static_cast<uint32_t>(v) << (bit % 32);
        bit += 4;
    }
    return w;
}

std::string row_hex(const Row128& r) {
    char buf[33];
    std::snprintf(buf, sizeof buf, "%08x%08x%08x%08x", r[3], r[2], r[1], r[0]);
    return buf;
}

}  // namespace

DecompSim::DecompSim(uint64_t max_steps, bool verbose, bool release_at_edge)
    : max_steps_(max_steps), verbose_(verbose), release_at_edge_(release_at_edge), ref_(kNumSubdecs) {}

// final() is not called: the only final blocks in the RTL print simulation statistics.
DecompSim::~DecompSim() = default;

// ------------------------------------------------------------------ reference rows
void DecompSim::load_reference(const std::string& stem) {
    for (int s = 0; s < kNumSubdecs; ++s) {
        const std::string path = stem + "_subdec" + std::to_string(s) + "_rows.hex";
        std::ifstream f(path);
        if (!f) throw std::runtime_error("Cannot open " + path);
        std::string tok;
        for (int i = 0; i < kNumRows; ++i) {
            if (!(f >> tok)) {
                throw std::runtime_error("Rows file short at row " + std::to_string(i) + " in " + path);
            }
            ref_[s][i] = parse_hex<4>(tok);
        }
    }
    has_ref_ = true;
}

void DecompSim::clear_reference() { has_ref_ = false; }

// ------------------------------------------------------------------ clocking
void DecompSim::eval() {
    g_active = this;
    top_->eval();
    g_active = nullptr;
}

void DecompSim::note_rtl_stop(const std::string& what) {
    if (rtl_stop_.empty()) rtl_stop_ = what;
}

void DecompSim::posedge() {
    // Settle the inputs driven at the falling edge, then sample what `always @(posedge clk)`
    // blocks in the testbench would see (values just before the edge).
    eval();
    const bool rst_n = top_->rst_n;
    const uint8_t pop = top_->cmd_pop;
    const uint8_t lane_v = top_->lane_row_valid;
    const uint8_t lane_r = top_->lane_row_ready;
    const bool pin_v = top_->row_valid;
    std::array<Row128, kNumSubdecs> lane_rows{}, pin_rows{};
    if (rst_n) {
        for (int s = 0; s < kNumSubdecs; ++s) {
            if ((lane_v >> s) & (lane_r >> s) & 1) lane_rows[s] = lane_row(s);
            if (pin_v) pin_rows[s] = pin_row(s);
        }
    }

    ctx_->timeInc(5);
    top_->clk = 1;
    eval();

    if (!rst_n) {
        cmd_popped_.fill(0);
        rows_emitted_.fill(0);
        mismatch_cnt_.fill(0);
        lane_mm_total_ = 0;
        outp_pulses_ = 0;
        outp_rows_ = 0;
        total_mismatches_ = 0;
        return;
    }

    // blk_cmd_popped
    for (int s = 0; s < kNumSubdecs; ++s)
        if ((pop >> s) & 1) ++cmd_popped_[s];

    // blk_lane_check
    int inc = 0;
    for (int s = 0; s < kNumSubdecs; ++s) {
        if (!(((lane_v >> s) & (lane_r >> s)) & 1)) continue;
        if (rows_emitted_[s] >= kNumRows) continue;
        if (has_ref_ && !row_matches(lane_rows[s], s, rows_emitted_[s])) {
            if (verbose_ && mismatch_cnt_[s] < 3)
                std::printf("    LANE%d MISMATCH row %d : exp %s  got %s\n", s, rows_emitted_[s],
                            row_hex(ref_[s][rows_emitted_[s]]).c_str(), row_hex(lane_rows[s]).c_str());
            ++mismatch_cnt_[s];
            ++inc;
        }
        ++rows_emitted_[s];
    }
    lane_mm_total_ += inc;

    // blk_outpin_check
    if (pin_v) {
        ++outp_pulses_;
        if (outp_rows_ < kNumRows) {
            bool cyc_mm = false;
            if (has_ref_) {
                for (int s = 0; s < kNumSubdecs; ++s) {
                    if (!row_matches(pin_rows[s], s, outp_rows_)) {
                        if (verbose_)
                            std::printf("Error: [HARDWARE MISMATCH] Sub-decoder %d at Row %d\n", s, outp_rows_);
                        cyc_mm = true;
                    }
                }
            }
            if (cyc_mm) ++total_mismatches_;
            ++outp_rows_;
        }
    }
}

void DecompSim::negedge() {
    ctx_->timeInc(5);
    top_->clk = 0;
    eval();
}

void DecompSim::drive(bool valid, const Beat135& data) {
    top_->in_valid = valid;
    for (int i = 0; i < 5; ++i) top_->in_data[i] = data[i];
    top_->in_data[4] &= 0x7Fu;   // 135 bits
}

void DecompSim::enter_decision_point() {
    ++wall_cyc_;
    if (wall_cyc_ > max_steps_) {
        throw std::runtime_error("WATCHDOG: " + std::to_string(wall_cyc_) +
                                 " RL steps without finishing");
    }
}

// ------------------------------------------------------------------ reset / step
void DecompSim::reset() {
    top_.reset();
    ctx_ = std::make_unique<VerilatedContext>();
    ctx_->debug(0);
    top_ = std::make_unique<Vrl_top_wrapper>(ctx_.get(), "TOP");

    wall_cyc_ = 0;
    rtl_stop_.clear();
    cmd_popped_.fill(0);
    cmd_committed_.fill(0);
    rows_emitted_.fill(0);
    mismatch_cnt_.fill(0);
    outp_rows_ = outp_pulses_ = total_mismatches_ = lane_mm_total_ = 0;
    proto_err_ = tailbusy_hits_ = cmd_overcommit_ = ready_viol_ = 0;

    top_->clk = 0;
    top_->rst_n = 0;
    drive(false, Beat135{});
    eval();

    // rst_n = 0; repeat (10) @(posedge clk); rst_n = 1; repeat (5) @(posedge clk);
    for (int i = 0; i < 10; ++i) {
        // rst_n rising does not trigger the async-reset flops (they use negedge rst_n), so
        // raising it before the edge just means the flops see it released at this edge.
        if (i == 9 && release_at_edge_) top_->rst_n = 1;
        posedge();
        if (i == 9 && !release_at_edge_) {
            top_->rst_n = 1;
            eval();
        }
        negedge();
    }
    for (int i = 0; i < 5; ++i) {
        posedge();
        negedge();
    }
    if (!rtl_stop_.empty()) throw RtlStop("RTL stopped during reset: " + rtl_stop_);
    started_ = true;
    enter_decision_point();
}

void DecompSim::check_beat(bool valid, const Beat135& data) {
    if (!valid) return;
    const int dest = static_cast<int>((data[4] >> 3) & 0xF);
    const int ncmd = static_cast<int>(data[4] & 0x7) + 1;
    auto slot = [&](int k) -> uint16_t {
        return static_cast<uint16_t>(data[k / 2] >> (16 * (k % 2)));
    };

    if (!in_ready()) {
        ++ready_viol_;
        if (verbose_ && ready_viol_ <= 5)
            std::printf("[CHK] VIOLATION: beat to addr %d driven while top_in_ready=0 (step %llu)\n",
                        dest, static_cast<unsigned long long>(wall_cyc_));
    }
    if (dest >= kNumSubdecs) {
        ++proto_err_;
        return;
    }
    if (tail_busy(dest)) ++tailbusy_hits_;

    int slots = 0;
    bool bad = false;
    for (int g = 0; g < ncmd && !bad; ++g) {
        if (slots >= 8) {
            bad = true;
        } else {
            const uint16_t cw = slot(slots);
            const int gsize = (cw >> 15) ? 2 : 1 + ((cw >> 11) & 0xF);
            if (slots + gsize > 8) bad = true;
            else slots += gsize;
        }
    }
    if (bad) {
        ++proto_err_;
    } else {
        for (int k = slots; k < 8; ++k) {
            if (slot(k) != 0) {
                ++proto_err_;
                break;
            }
        }
    }

    cmd_committed_[dest] += ncmd;
    if (cmd_committed_[dest] - cmd_popped_[dest] > kCmdFifoDepth) ++cmd_overcommit_;
}

void DecompSim::step(bool valid, const Beat135& data) {
    if (!started_) throw std::logic_error("step() before reset() (or after the RTL stopped)");
    check_beat(valid, data);
    drive(valid, data);
    posedge();
    negedge();
    enter_decision_point();
    if (!rtl_stop_.empty()) {
        started_ = false;
        throw RtlStop("RTL stopped at cycle " + std::to_string(wall_cyc_ - 1) + ": " + rtl_stop_);
    }
}

void DecompSim::step_hex(bool valid, const std::string& hex) {
    step(valid, parse_hex<5>(hex));
}

void DecompSim::step_beat(int dest, int ncmd, const std::array<uint16_t, 8>& slots) {
    if (ncmd < 1 || ncmd > 8) throw std::invalid_argument("ncmd must be 1..8");
    Beat135 d{};
    for (int k = 0; k < 8; ++k) d[k / 2] |= static_cast<uint32_t>(slots[k]) << (16 * (k % 2));
    d[4] = (static_cast<uint32_t>(dest & 0xF) << 3) | static_cast<uint32_t>(ncmd - 1);
    step(true, d);
}

void DecompSim::step_idle() {
    step(false, Beat135{});
}

int DecompSim::skip_until_ready(int max_cycles) {
    int n = 0;
    while (n < max_cycles && !in_ready()) {
        step_idle();
        ++n;
    }
    return n;
}

// ------------------------------------------------------------------ observation
bool DecompSim::in_ready() const { return top_->in_ready; }
bool DecompSim::row_valid() const { return top_->row_valid; }
bool DecompSim::tail_busy(int s) const { return (top_->tail_busy >> s) & 1; }

LaneCounts DecompSim::lane_counts(int s) const {
    auto b = [s](uint64_t v) { return static_cast<int>((v >> (8 * s)) & 0xFF); };
    return {b(top_->cnt_cmd), b(top_->cnt_lit1), b(top_->cnt_lit2),
            b(top_->cnt_lit3), b(top_->cnt_lit4), b(top_->cnt_out)};
}

Row128 DecompSim::lane_row(int s) const {
    return {top_->lane_row_data[4 * s], top_->lane_row_data[4 * s + 1],
            top_->lane_row_data[4 * s + 2], top_->lane_row_data[4 * s + 3]};
}

Row128 DecompSim::pin_row(int s) const {
    return {top_->row_data[4 * s], top_->row_data[4 * s + 1],
            top_->row_data[4 * s + 2], top_->row_data[4 * s + 3]};
}

bool DecompSim::row_matches(const Row128& got, int s, int row) const {
    return got == ref_[s][row];
}

int DecompSim::rows_consumed() const {
    // Free-run: the slowest lane's row count (the barrier variant is not supported here).
    return *std::min_element(rows_emitted_.begin(), rows_emitted_.end());
}

std::array<int64_t, kObsFields> DecompSim::obs_fields() const {
    std::array<int64_t, kObsFields> f{};
    int k = 0;
    f[k++] = in_ready();
    f[k++] = row_valid();
    f[k++] = total_mismatches_;
    for (int s = 0; s < kNumSubdecs; ++s) {
        const LaneCounts c = lane_counts(s);
        f[k++] = c.cmd;
        f[k++] = c.lit1;
        f[k++] = c.lit2;
        f[k++] = c.lit3;
        f[k++] = c.lit4;
        f[k++] = c.out;
    }
    for (int s = 0; s < kNumSubdecs; ++s) f[k++] = tail_busy(s);
    for (int s = 0; s < kNumSubdecs; ++s) f[k++] = cmd_popped_[s];
    f[k++] = outp_rows_;
    f[k++] = rows_consumed();
    f[k++] = lane_mm_total_;
    f[k++] = proto_err_;
    f[k++] = tailbusy_hits_;
    f[k++] = cmd_overcommit_;
    f[k++] = ready_viol_;
    return f;
}

std::string DecompSim::obs_line() const {
    const auto f = obs_fields();
    std::ostringstream os;
    os << "@OBS";
    for (int k = 0; k < kObsFields; ++k) os << ' ' << f[k];
    return os.str();
}

}  // namespace decomp

// ------------------------------------------------------------------ Verilator runtime hooks
// Built with -DVL_USER_STOP -DVL_USER_FINISH -DVL_USER_FATAL so the defaults (which abort the
// whole process) are replaced by these. Verilator's vl_stop_maybe ($stop from $error) calls vl_stop.
namespace {
std::string where(const char* filename, int linenum, const char* hier) {
    return std::string(filename ? filename : "?") + ":" + std::to_string(linenum) + " in " +
           (hier ? hier : "?");
}
void record(const std::string& what) {
    if (decomp::g_active) decomp::g_active->note_rtl_stop(what);
}
}  // namespace

void vl_stop(const char* filename, int linenum, const char* hier) {
    record("$stop at " + where(filename, linenum, hier));
}
void vl_finish(const char* filename, int linenum, const char* hier) {
    record("$finish at " + where(filename, linenum, hier));
}
void vl_fatal(const char* filename, int linenum, const char* hier, const char* msg) {
    // A fatal error may leave the model mid-evaluation: give up on this cycle right away.
    const std::string what = std::string("fatal at ") + where(filename, linenum, hier) + ": " +
                             (msg ? msg : "");
    record(what);
    throw decomp::RtlStop(what);
}
