// rl_top_wrapper -- the DUT exactly as tb_interactive.sv instantiates it, with every internal
// signal that testbench reads routed to a top-level port, so a C++ harness can drive it and
// read the same state without hierarchical access.
//
// Same parameters and the same constant register inputs as tb_interactive.sv (free-run). The
// BARRIER_EN branches are kept so the file mirrors the testbench, but the C++ harness only
// implements the free-run rows_consumed field and the Makefile does not define BARRIER_EN.
//
// Internal paths (identical to the ones tb_interactive.sv reads):
//   cmd/lit FIFO counts : u_top.g_sub[s].u_dut.U_cmd_fifo.count, U_lit_bank1..4.count
//   row-queue count     : u_top.g_sub[s].u_dut.u_row_q.U_q.count
//   tail busy           : u_top.arb_tail_busy[s]
//   CMD pop strobe      : ~u_top.g_sub[s].u_dut.cmd_fifo_pop_req_n_w
//   per-lane rows       : u_top.row_data_array[s], row_valid_array[s], row_ready_array[s]

module rl_top_wrapper #(
    parameter integer ROW_QUEUE_DEPTH = 4,
    parameter integer NUM_SUBDECS     = 8,
    parameter integer TOTAL_ROW_W     = 8*128 + 56
) (
    input  wire                          clk,
    input  wire                          rst_n,

    // bus input
    input  wire [134:0]                  in_data,
    input  wire                          in_valid,
    output wire                          in_ready,

    // output pin
    output wire [TOTAL_ROW_W-1:0]        row_data,
    output wire                          row_valid,

    // per-lane FIFO occupancy, 8 bits per lane, lane s at [8*s +: 8]
    output wire [8*NUM_SUBDECS-1:0]      cnt_cmd,
    output wire [8*NUM_SUBDECS-1:0]      cnt_lit1,
    output wire [8*NUM_SUBDECS-1:0]      cnt_lit2,
    output wire [8*NUM_SUBDECS-1:0]      cnt_lit3,
    output wire [8*NUM_SUBDECS-1:0]      cnt_lit4,
    output wire [8*NUM_SUBDECS-1:0]      cnt_out,

    // arbiter / CMD FIFO
    output wire [NUM_SUBDECS-1:0]        tail_busy,
    output wire [NUM_SUBDECS-1:0]        cmd_pop,

    // per-lane row handshake (before the output stage), lane s at [128*s +: 128]
    output wire [128*NUM_SUBDECS-1:0]    lane_row_data,
    output wire [NUM_SUBDECS-1:0]        lane_row_valid,
    output wire [NUM_SUBDECS-1:0]        lane_row_ready
);

    wire [TOTAL_ROW_W-1:0] row_data_n_unused;

    new_dec_top_complete #(
        .ROW_QUEUE_DEPTH(ROW_QUEUE_DEPTH)
    ) u_top (
        .clkm                            (clk),
        .rst_n                           (rst_n),
        .in_data                         (in_data),
        .in_valid                        (in_valid),
        .in_ready                        (in_ready),
        .in_mask_en_unsync               (1'b1),
        .row_data                        (row_data),
        .row_data_n                      (row_data_n_unused),
        .row_valid                       (row_valid),
        .ds_row_toggle                   (1'b1),
        .reg_bus_mode                    (1'b0),
`ifdef BARRIER_EN
        .reg_force_ds_row_toggle         (1'b0),
        .reg_ds_row_toggle_level_mode    (1'b1),
`else
        .reg_force_ds_row_toggle         (1'b1),
        .reg_ds_row_toggle_level_mode    (1'b0),
`endif
        .reg_ds_row_toggle_edge_polarity (1'b0),
        .reg_disable_decomp              (1'b0),
        .reg_disable_sub                 (8'b0),
        .reg_disable_bypass              (1'b1),
`ifdef BARRIER_EN
        .reg_disable_barrier             (1'b0),
`else
        .reg_disable_barrier             (1'b1),
`endif
        .reg_disable_row_valid           (1'b0),
        .reg_force_row_data_zero         (1'b0),
        .reg_invert_output               (1'b0),
        .reg_enable_non_ex               (1'b0),
        .reg_non_ex_start_polarity       (1'b0)
    );

    genvar s;
    generate
        for (s = 0; s < NUM_SUBDECS; s = s + 1) begin : g_expose
            assign cnt_cmd [8*s +: 8] = 8'(u_top.g_sub[s].u_dut.U_cmd_fifo.count);
            assign cnt_lit1[8*s +: 8] = 8'(u_top.g_sub[s].u_dut.U_lit_bank1.count);
            assign cnt_lit2[8*s +: 8] = 8'(u_top.g_sub[s].u_dut.U_lit_bank2.count);
            assign cnt_lit3[8*s +: 8] = 8'(u_top.g_sub[s].u_dut.U_lit_bank3.count);
            assign cnt_lit4[8*s +: 8] = 8'(u_top.g_sub[s].u_dut.U_lit_bank4.count);
            assign cnt_out [8*s +: 8] = 8'(u_top.g_sub[s].u_dut.u_row_q.U_q.count);

            assign tail_busy[s] = u_top.arb_tail_busy[s];
            assign cmd_pop[s]   = ~u_top.g_sub[s].u_dut.cmd_fifo_pop_req_n_w;

            assign lane_row_data[128*s +: 128] = u_top.row_data_array[s];
            assign lane_row_valid[s]           = u_top.row_valid_array[s];
            assign lane_row_ready[s]           = u_top.row_ready_array[s];
        end
    endgenerate

endmodule
