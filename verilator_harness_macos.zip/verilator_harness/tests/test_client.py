#!/usr/bin/env python3
"""Drive VerilatorSimClient with the exact call sequence DecoderEnvXSim uses, check that the run
completes, and time the two paths (text @OBS round trip vs. direct calls).

Usage: python3 test_client.py --stem /path/to/4_comp_data/test_11_lantern [--episodes 2]
"""
import argparse
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "python"))
sys.path.insert(0, str(HERE))
import decomp_sim  # noqa: E402
from test_equivalence import INFLIGHT_GATE, NUM, beat_int, load_tokens, pack  # noqa: E402
from verilator_sim_client import VerilatorSimClient  # noqa: E402


def parse_obs_line(line: str) -> list[int]:
    return [int(x) for x in line.split()[1:]]


def episode_text_path(client: VerilatorSimClient, stem: str, first: bool) -> tuple[int, float]:
    """Mirror env.reset() / env.step(): every cycle goes through write_action/resume/wait_for_obs."""
    state = {}

    def on_obs(line):
        state["f"] = parse_obs_line(line)

    if first:
        client.start()
    else:
        client.restart()
    client.resume(); client.wait_for_obs(on_obs)                   # handshake
    client.write_action(stem)
    client.resume(); client.wait_for_obs(on_obs)                   # reset + first @OBS
    lanes, committed, rr, cycles = load_tokens(stem), [0] * NUM, 0, 0
    t0 = time.perf_counter()
    while True:
        f = state["f"]
        in_ready, busy, popped = f[0], f[51:59], f[59:67]
        action = "0 0"
        if in_ready:
            for k in range(NUM):
                s = (rr + k) % NUM
                if lanes[s] and not busy[s] and committed[s] - popped[s] <= INFLIGHT_GATE:
                    ncmd, slots = pack(lanes[s])
                    committed[s] += ncmd
                    action = f"1 {beat_int(s, ncmd, slots):x}"
                    rr = (s + 1) % NUM
                    break
        client.write_action(action)
        client.resume(); client.wait_for_obs(on_obs)
        cycles += 1
        if min(client.sim.rows_emitted()) >= 720 and not any(lanes):
            return cycles, time.perf_counter() - t0


def episode_fast_path(sim: decomp_sim.DecompSim, stem: str) -> tuple[int, float, int]:
    """Same policy, direct calls; idle cycles while in_ready is low run inside C++."""
    sim.load_reference(stem)
    sim.reset()
    lanes, committed, rr, decisions = load_tokens(stem), [0] * NUM, 0, 0
    t0 = time.perf_counter()
    while True:
        if not sim.in_ready:
            sim.skip_until_ready(1_000_000)
        busy, popped = sim.tail_busy(), sim.cmd_popped()
        sent = False
        for k in range(NUM):
            s = (rr + k) % NUM
            if lanes[s] and not busy[s] and committed[s] - popped[s] <= INFLIGHT_GATE:
                ncmd, slots = pack(lanes[s])
                committed[s] += ncmd
                sim.step_beat(s, ncmd, slots + [0] * (8 - len(slots)))
                rr = (s + 1) % NUM
                sent = True
                break
        if not sent:
            sim.step_idle()
        decisions += 1
        if min(sim.rows_emitted()) >= 720 and not any(lanes):
            return sim.cycle - 1, time.perf_counter() - t0, decisions


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stem", required=True)
    ap.add_argument("--episodes", type=int, default=2)
    args = ap.parse_args()

    client = VerilatorSimClient()
    for ep in range(args.episodes):
        cycles, dt = episode_text_path(client, args.stem, first=(ep == 0))
        sim = client.sim
        ok = sim.lane_mismatches == 0 and sim.proto_err == 0 and sim.cmd_overcommit == 0
        print(f"text path  episode {ep}: makespan {cycles} cycles, {dt * 1e3:.0f} ms "
              f"({cycles / dt:,.0f} cycles/s), clean={ok}")
        assert ok

    # hw_state_dict() must carry the same numbers as the @OBS line.
    h = client.hw_state_dict()
    f = parse_obs_line(client.sim.obs_line())
    assert [h["top_in_ready"], h["top_row_valid"], h["mismatches"]] == f[0:3]
    assert [v for d in h["sub_decoders"] for v in d.values()] == f[3:51]
    assert h["tail_busy"] + h["cmd_popped"] == f[51:67]
    assert [h[k] for k in ("rows_out", "rows_consumed", "lane_mismatches", "proto_err",
                           "tailbusy_hits", "cmd_overcommit", "ready_viol")] == f[67:74]
    print("hw_state_dict() agrees with the @OBS line")

    sim = decomp_sim.DecompSim()
    for ep in range(args.episodes):
        cycles, dt, decisions = episode_fast_path(sim, args.stem)
        print(f"fast path  episode {ep}: makespan {cycles} cycles, {decisions} policy calls, "
              f"{dt * 1e3:.0f} ms ({cycles / dt:,.0f} cycles/s)")

    # Same policy => same makespan on both paths.
    print("PASS")


if __name__ == "__main__":
    main()
