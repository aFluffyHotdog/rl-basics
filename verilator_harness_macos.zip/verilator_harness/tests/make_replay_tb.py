#!/usr/bin/env python3
"""Turn tb_interactive.sv into tb_interactive_replay.sv: same DUT, checks and @OBS output, but it
reads the image stem from +STEM=<prefix> and one action per cycle from +TRACE=<file> ("%b %h"
lines, as Python writes to action.txt) instead of the $stop / action.txt handshake.

The replay testbench is the reference for tests/test_equivalence.py.
Usage: python3 make_replay_tb.py <tb_interactive.sv> <out.sv>
"""
import re
import sys

src = open(sys.argv[1]).read()

# wall_cyc_r is used in check_beat before its declaration; move the declaration up.
decl = "int           wall_cyc_r = 0;\n"
assert src.count(decl) == 1
src = src.replace(decl, "")
src = src.replace("int proto_err      = 0;", decl + "int proto_err      = 0;", 1)

# Handshake: stem from a plusarg instead of $stop + action.txt.
hs_start = src.index('    $display("@HANDSHAKE_READY");')
hs_end = src.index("    load_all_subdecs(img_stem_path);")
src = src[:hs_start] + (
    '    if (!$value$plusargs("STEM=%s", img_stem_path)) begin\n'
    '        $display("FATAL: +STEM=<prefix> missing"); $finish;\n'
    '    end\n'
    '    if (!$value$plusargs("TRACE=%s", trace_path)) begin\n'
    '        $display("FATAL: +TRACE=<file> missing"); $finish;\n'
    '    end\n'
    '    fd_tr = $fopen(trace_path, "r");\n'
    '    if (fd_tr == 0) begin $display("FATAL: cannot open trace"); $finish; end\n'
) + src[hs_end:]
src = src.replace("string  img_stem_path;", "string  img_stem_path;\nstring  trace_path;\ninteger fd_tr;", 1)

# Per-step: no $stop, read the next trace line.
step_start = src.index("        // 2. Freeze simulation clock")
step_end = src.index("        if (scan_ret != 2) begin")
src = src[:step_start] + '        scan_ret = $fscanf(fd_tr, "%b %h", py_beat_valid, py_beat_data);\n\n' + src[step_end:]

assert "$stop" not in src, "a $stop is left"
open(sys.argv[2], "w").write(src)
print("wrote", sys.argv[2])
