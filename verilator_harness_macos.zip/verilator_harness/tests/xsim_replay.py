#!/usr/bin/env python3
"""The final check against real xsim: record a session from your current env, replay it here.

1. Record (in your project, with xsim). Wrap the existing client once:

       from verilator_harness.tests.xsim_replay import RecordingClient
       self.sim = RecordingClient(XSimClient(self.run_dir, verbose=VIVADO_VERBOSE), "xsim_session.log")

   Run one or two episodes with any policy, then close the env. The log holds every call that
   matters (start, restart, write_action, resume) and every @OBS line, in order, so the replay
   makes exactly the calls the env made.

2. Replay (no xsim needed):

       python3 xsim_replay.py xsim_session.log [--next-edge]

   Feeds the same actions to VerilatorSimClient and requires every @OBS line to match.
   If the first difference shows up a few hundred cycles in and starts in tail_busy, rerun with
   --next-edge: that is the reset-release race described in csrc/decomp_sim.h, and whichever
   setting matches xsim is the one to use (release_at_edge=...).
"""
import argparse
import sys
from pathlib import Path


class RecordingClient:
    """Wraps any client with the XSimClient interface and logs actions and @OBS lines."""

    def __init__(self, inner, log_path):
        self._inner = inner
        self._log = open(log_path, "w")

    def __getattr__(self, name):          # start, restart, close, is_running, ...
        attr = getattr(self._inner, name)
        if name in ("start", "restart"):
            def wrapped(*a, **k):
                self._log.write(f"#{name}\n")
                self._log.flush()
                return attr(*a, **k)
            return wrapped
        return attr

    def write_action(self, text):
        self._log.write(f"A {text.strip()}\n")
        return self._inner.write_action(text)

    def resume(self, *a, **k):
        self._log.write("R\n")
        return self._inner.resume(*a, **k)

    def wait_for_obs(self, callback=None):
        def tee(line):
            self._log.write(f"O {line.strip()}\n")
            if callback is not None:
                callback(line)
        return self._inner.wait_for_obs(tee)

    def close(self):
        self._log.close()
        return self._inner.close()


def replay(log_path: str, release_at_edge: bool) -> bool:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))
    from verilator_sim_client import VerilatorSimClient

    client = VerilatorSimClient(release_at_edge=release_at_edge)
    got: list[str] = []
    expected: list[str] = []
    for raw in open(log_path):
        tag, _, rest = raw.rstrip("\n").partition(" ")
        if tag == "#start":
            client.start()
        elif tag == "#restart":
            client.restart()
        elif tag == "A":
            client.write_action(rest)
        elif tag == "R":
            client.resume()
            got += client.wait_for_obs()
        elif tag == "O":
            expected.append(rest)
    n = min(len(got), len(expected))
    bad = next((i for i in range(n) if got[i].split() != expected[i].split()), None)
    print(f"xsim lines {len(expected)}, harness lines {len(got)}, compared {n}")
    if bad is not None:
        print(f"first difference at line {bad}:\n  xsim   : {expected[bad]}\n  harness: {got[bad]}")
    ok = bad is None and len(got) == len(expected)
    print("PASS" if ok else "FAIL")
    return ok


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("log")
    ap.add_argument("--next-edge", action="store_true",
                    help="release reset one edge later (release_at_edge=False)")
    args = ap.parse_args()
    sys.exit(0 if replay(args.log, not args.next_edge) else 1)
