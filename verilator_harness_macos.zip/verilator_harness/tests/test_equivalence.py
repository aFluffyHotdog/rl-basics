#!/usr/bin/env python3
"""Check that DecompSim reproduces tb_interactive.sv cycle for cycle.

1. Drive DecompSim with a policy and record, every cycle, its @OBS line and the action taken.
2. Replay the same actions through tb_interactive_replay.sv (built by make_replay_tb.py).
3. Require every @OBS line to be identical.

Two policies:
  v20    legal round-robin packer with the v20 gates (in_ready, tail_busy, in-flight <= 8).
         Runs the image to completion and also checks 5760 rows out and 0 mismatches.
  chaos  random lanes, partial beats, gate violations (in_ready, CMD in-flight) and
         beats with payload beyond their declared groups, to exercise every counter in
         check_beat. Fixed number of cycles.
  stop   legal for 500 cycles, then a beat whose CMD group can never fit (the RTL asserts).
         The harness must raise RtlStop on the same cycle the reference stops.

Usage:
  python3 test_equivalence.py --ref /path/to/tb_ref --stem /path/to/4_comp_data/test_11_lantern \
      [--policy v20|chaos|both] [--cycles 4000] [--seed 0]
The stem is the data prefix: <stem>_subdec<s>_beats.hex and <stem>_subdec<s>_rows.hex.
"""
import argparse
import random
import subprocess
import sys
import tempfile
from collections import deque
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))
import decomp_sim  # noqa: E402

NUM = 8
INFLIGHT_GATE = 8


def load_tokens(stem: str):
    lanes = []
    for s in range(NUM):
        toks = [int(l, 16) for l in open(f"{stem}_subdec{s}_beats.hex") if l.strip()]
        lanes.append(deque(toks))
    return lanes


def group_size(tok: int) -> int:
    ty, p = (tok >> 16) & 0xF, tok & 0xFFFF
    if ty == 2 or (ty == 0 and p >> 15):
        return 2
    return 1 + ((p >> 11) & 0xF)


def pack(q: deque, max_slots: int = 8):
    """Greedy, order-preserving: whole groups while they fit. Returns (ncmd, slot words)."""
    slots, ncmd = [], 0
    while q:
        g = group_size(q[0])
        if len(slots) + g > max_slots or g > len(q):
            break
        slots += [q.popleft() & 0xFFFF for _ in range(g)]
        ncmd += 1
    return ncmd, slots


def beat_int(dest: int, ncmd: int, slots) -> int:
    v = (dest << 131) | ((ncmd - 1) << 128)
    for k, w in enumerate(slots):
        v |= w << (16 * k)
    return v


def run_policy(sim, lanes, policy: str, cycles: int, rng: random.Random):
    """Returns (obs_lines, trace_lines)."""
    obs, trace = [sim.obs_line()], []
    committed = [0] * NUM
    rr = 0
    for _ in range(cycles):
        action = (0, 0)
        popped = sim.cmd_popped()
        busy = sim.tail_busy()
        if policy == "v20":
            if sim.in_ready:
                for k in range(NUM):
                    s = (rr + k) % NUM
                    if lanes[s] and not busy[s] and committed[s] - popped[s] <= INFLIGHT_GATE:
                        ncmd, slots = pack(lanes[s])
                        if ncmd:
                            committed[s] += ncmd
                            action = (1, beat_int(s, ncmd, slots))
                            rr = (s + 1) % NUM
                            break
        elif policy == "chaos":
            # Gate violations (in_ready, CMD in-flight) and partial beats. Lanes with a busy tail
            # are skipped: a beat there corrupts sub_rx and the RTL asserts within a few cycles.
            r = rng.random()
            s = rng.randrange(NUM)
            if r < 0.55 and lanes[s] and not busy[s]:
                ncmd, slots = pack(lanes[s], max_slots=rng.choice([2, 4, 8]))
                if ncmd:
                    action = (1, beat_int(s, ncmd, slots))
            elif r < 0.58 and lanes[s] and not busy[s]:
                # malformed: the lane's real next group(s), plus junk in a slot past them
                ncmd, slots = pack(lanes[s], max_slots=7)
                if ncmd:
                    slots = slots + [0] * (8 - len(slots))
                    slots[7] = 0x1234
                    action = (1, beat_int(s, ncmd, slots))
        if policy == "stop":
            if len(trace) == 500:
                action = (1, beat_int(2, 1, [0x7800, 0, 0, 0, 0, 0, 0, 0]))   # lit_field 15
            elif sim.in_ready:
                for k in range(NUM):
                    s = (rr + k) % NUM
                    if lanes[s] and not busy[s] and committed[s] - popped[s] <= INFLIGHT_GATE:
                        ncmd, slots = pack(lanes[s])
                        committed[s] += ncmd
                        action = (1, beat_int(s, ncmd, slots))
                        rr = (s + 1) % NUM
                        break
        valid, data = action
        trace.append(f"{valid} {data:x}")
        try:
            sim.step_int(bool(valid), data)
        except decomp_sim.RtlStop as e:
            print(f"  RtlStop after {len(trace)} actions: {e}")
            return obs, trace, len(trace)
        obs.append(sim.obs_line())
        if policy == "v20" and min(sim.rows_emitted()) >= 720 and not any(lanes):
            break
    return obs, trace, None


def run_reference(ref: str, stem: str, trace):
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False) as f:
        f.write("\n".join(trace) + "\n")
        path = f.name
    res = subprocess.run([ref, f"+STEM={stem}", f"+TRACE={path}"], capture_output=True, text=True,
                         check=False)
    lines = [l.rstrip() for l in res.stdout.splitlines() if l.startswith("@OBS")]
    stopped = "Verilog $stop" in res.stdout + res.stderr
    return lines, stopped


def check(policy, args):
    sim = decomp_sim.DecompSim()
    sim.load_reference(args.stem)
    sim.reset()
    lanes = load_tokens(args.stem)
    obs, trace, stop_at = run_policy(sim, lanes, policy, args.cycles, random.Random(args.seed))
    ref, ref_stopped = run_reference(args.ref, args.stem, trace)

    ok = len(ref) == len(obs)
    if policy == "stop":
        # The bad beat is action 501; the assertion fires once it reaches sub_rx (it can queue in the
        # arbiter first). Both simulators must stop on the same cycle: len(ref) == len(obs) above.
        expect = stop_at is not None and stop_at >= 501 and ref_stopped
        print(f"  harness stopped after action {stop_at}, reference stopped: {ref_stopped}")
        ok = ok and expect
    first_bad = next((i for i, (a, b) in enumerate(zip(obs, ref)) if a != b), None)
    identical = len(ref) == len(obs) and first_bad is None
    ok = ok and identical
    print(f"[{policy}] cycles={len(trace)} harness_lines={len(obs)} reference_lines={len(ref)} "
          f"identical={identical}")
    if first_bad is not None:
        print(f"  first difference at line {first_bad}:\n  harness  : {obs[first_bad]}\n"
              f"  reference: {ref[first_bad]}")
    if policy == "stop":
        return ok
    print(f"  rows_emitted={list(sim.rows_emitted())} lane_mismatches={sim.lane_mismatches} "
          f"proto_err={sim.proto_err} tailbusy_hits={sim.tailbusy_hits} "
          f"cmd_overcommit={sim.cmd_overcommit} ready_viol={sim.ready_viol}")
    if policy == "v20":
        done = min(sim.rows_emitted()) == 720 and sim.lane_mismatches == 0
        print(f"  image complete with 0 lane mismatches: {done}  (makespan {sim.cycle - 1} cycles)")
        ok = ok and done
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ref", required=True)
    ap.add_argument("--stem", required=True)
    ap.add_argument("--policy", default="all", choices=["v20", "chaos", "stop", "all"])
    ap.add_argument("--cycles", type=int, default=20000)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    policies = ["v20", "chaos", "stop"] if args.policy == "all" else [args.policy]
    results = [check(p, args) for p in policies]
    print("PASS" if all(results) else "FAIL")
    sys.exit(0 if all(results) else 1)


if __name__ == "__main__":
    main()
