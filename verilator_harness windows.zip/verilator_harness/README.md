# Verilator harness for the T8 decompressor RL env

A C++ replacement for `tb_interactive.sv`, driving the Verilated RTL, with Python bindings and a
drop-in replacement for `XSimClient`. Same reset sequence, same sample points, same checks, same
`@OBS` lines, about 750× faster than the xsim ping-pong (one lantern episode: ~45 ms through the
drop-in client, ~20 ms through direct calls, vs ~35 s).

```
rtl/rl_top_wrapper.sv           DUT as tb_interactive.sv instantiates it; internal signals -> ports
csrc/decomp_sim.{h,cpp}         C++ harness (the testbench's loop, checks and counters)
csrc/bindings.cpp               pybind11 module `decomp_sim`
python/verilator_sim_client.py  drop-in XSimClient replacement
tests/make_replay_tb.py         tb_interactive.sv -> trace-replay testbench (the reference)
tests/test_equivalence.py       harness vs reference, @OBS line by line
tests/test_client.py            env call sequence through the client, plus timing
tests/xsim_replay.py            record a real xsim session, replay it through the harness
```

## Build

Needs Verilator ≥ 5.0, a C++17 compiler, Python 3 with `pybind11` (`pip install pybind11`).
On Windows, use WSL2.

```bash
make RTL_DIR=/path/to/rtl/new_decomp_v20_from_v19/clean
# -> python/decomp_sim.<python-abi>.so
```

Use the same `clean/` RTL your xsim flow compiles. `DW_fifo_s1_sf.v` in that directory is the
FIFO model; it is picked up with the rest.

## Use it in the env

One import in `env.py`:

```python
from .verilator_sim_client import VerilatorSimClient as XSimClient
```

with `python/` (the client and the `.so`) copied into your package or put on `sys.path`. The
client answers `start`, `restart`, `write_action`, `resume`, `wait_for_obs`, `close`, `is_running`
exactly as the env uses them; `run_dir` and `verbose` are accepted and the run dir is ignored.

Differences from xsim:

- **RTL `$stop` raises `decomp_sim.RtlStop`.** The RTL asserts on some malformed beats (for example a
  CMD group that cannot fit in 8 slots, or a beat to a lane whose tail is busy, which corrupts
  `sub_rx`). xsim would pause and the env would keep reading stale state. Here the cycle completes,
  `resume()` raises, and the client refuses to step until `restart()`. Catch it in `env.step()` and
  return a failure terminal.
- No `action.txt`, no subprocess, no Tcl, no periodic restart needed (`max_episodes_per_vivado_process`
  can go).
- The watchdog (`max_steps`, default 1,000,000 cycles) raises `RuntimeError` instead of `$finish`.

## Faster: skip the text round trip

The drop-in client still formats an `@OBS` line every cycle and the env still parses it. For more
speed, call the module directly:

```python
import decomp_sim
sim = decomp_sim.DecompSim()
sim.load_reference(stem)         # <stem>_subdec<s>_rows.hex
sim.reset()                      # at the first decision point, cycle 1
sim.step_beat(lane, ncmd, slots) # one cycle with a beat: 8 slot words (16-bit)
sim.step_idle()                  # one cycle without
n = sim.skip_until_ready(10_000) # idle cycles while in_ready is low, run in C++
sim.lane_counts()                # int32[8, 6]: cmd, lit1..lit4, out
sim.tail_busy(), sim.cmd_popped(), sim.rows_emitted()   # int32[8] each
sim.in_ready, sim.cycle, sim.proto_err, ...             # scalars
```

`rows_emitted()` is the exact number of rows each lane has output (the testbench's lane-checker
count). It can replace the env's per-cycle row reconstruction in `LowerBoundTracker`.

`VerilatorSimClient.hw_state_dict()` builds `hw_state` from these without text. Its key names are
inferred from `env.py`; check once against your parser before relying on it:

```python
assert client.hw_state_dict() == parse_obs_line(client.sim.obs_line())
```

`skip_until_ready()` only pays off if the env's per-cycle bookkeeping (`_tick`: lower bound, row
counter, throughput window, `cycles_since_fed`, stall counter) no longer needs every cycle. With
`rows_emitted()` from the harness, most of it doesn't.

## Verification done

Against `tb_interactive.sv` itself, converted to replay a recorded action trace and Verilated
(`make reference RTL_DIR=... TB=.../tb_interactive.sv`, then
`python3 tests/test_equivalence.py --ref ref_obj/tb_ref --stem <data>/test_11_lantern`):

| policy | what it does | result (lantern, tulip, items, qrcode) |
|---|---|---|
| `v20` | legal round-robin with the v20 gates, image to completion | every `@OBS` line identical, 5,760 rows, 0 mismatches |
| `chaos` | random lanes, partial beats, `in_ready` and in-flight violations, junk after declared groups | 8,000–20,000 cycles identical; `proto_err` and `cmd_overcommit` exercised |
| `stop` | an impossible CMD group at action 501 | RTL assertion and `RtlStop` on the same cycle as the reference |

Not exercised: `tailbusy_hits` and `ready_viol` never incremented (beats to a busy tail make the RTL
assert within a few cycles, so the chaos policy avoids them). Both are one-line counters.

## Still to verify against real xsim

The reference above is the testbench under Verilator, not under xsim. One thing can differ:

**Reset release.** The testbench sets `rst_n = 1` in the same time step as the 10th rising edge,
which is a Verilog race. Verilator lets the flops see the release at that edge; the harness does the
same by default (`release_at_edge=True`), because the v20 testbench under Verilator matched xsim
cycle for cycle with skid promotions active. It matters: the arbiter's free-running `skid_try_r`
counter keeps that phase forever, and on lantern the other phase changes the first skid at cycle
632 and the makespan of the same policy by 16 cycles (2,421 vs 2,437).

Settle it with one recorded xsim session:

```python
# in env.__init__, temporarily:
from .tests.xsim_replay import RecordingClient   # or copy the class
self.sim = RecordingClient(XSimClient(self.run_dir, verbose=VIVADO_VERBOSE), "xsim_session.log")
```

Run one or two episodes, close the env, then:

```bash
python3 tests/xsim_replay.py xsim_session.log           # release_at_edge=True
python3 tests/xsim_replay.py xsim_session.log --next-edge   # if the first fails near a skid
```

Whichever passes is the setting to use (`VerilatorSimClient(release_at_edge=...)`). If neither
passes, the first differing line says where to look. The replay was self-tested with a two-episode
session through this client: it passes with the matching setting and fails at line 632 with the
other, so it does detect the phase.

## Notes

- One `DecompSim` per env; several in one process are fine (each has its own Verilator context).
  The step calls release the GIL.
- `reset()` builds a fresh model, so every episode starts from the same state, like an xsim restart.
- Data: there are several versions of the lantern hex files in circulation (the RL env's
  `sample_data_9_lanes`, the fork's `4_comp_data`, a fresh `comp_data_gen.py` run). Pin one; makespans
  are only comparable on identical data.
